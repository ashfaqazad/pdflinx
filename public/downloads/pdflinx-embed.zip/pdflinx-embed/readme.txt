=== PDFLinx Embed ===
Contributors: pdflinx
Tags: pdf, compress pdf, merge pdf, embed, iframe, pdf tools
Requires at least: 5.8
Tested up to: 6.5
Stable tag: 1.0.0
License: GPLv2 or later

Embed free PDF tools from PDFLinx.com into any WordPress page or post.

== Description ==

Add powerful, browser-based PDF tools to your website for free — no API key, no signup required.

**Available Tools:**
* 🗜️ Compress PDF
* 🔗 Merge PDF
* ✂️ Split PDF
* 📝 PDF to Word
* 📄 Word to PDF
* 🖼️ JPG to PDF
* 🗃️ PDF to JPG

**Two ways to embed:**

= Shortcode =
`[pdflinx tool="compress-pdf"]`
`[pdflinx tool="merge-pdf" layout="sidebar"]`

**layout options:** `normal` (680px) or `sidebar` (340px)

= Gutenberg Block =
Search for "PDFLinx Tool" in the block inserter — select your tool and layout from the sidebar panel.

== Installation ==

1. Upload the `pdflinx-embed` folder to `/wp-content/plugins/`
2. Activate the plugin in WordPress Admin → Plugins
3. Use shortcode `[pdflinx tool="compress-pdf"]` or add the PDFLinx block in the editor

== Changelog ==

= 1.0.0 =
* Initial release — shortcode + Gutenberg block support
