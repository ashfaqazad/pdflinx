( function( blocks, element, editor, components, i18n ) {
    var el         = element.createElement;
    var __         = i18n.__;
    var InspectorControls = editor.InspectorControls;
    var PanelBody  = components.PanelBody;
    var SelectControl = components.SelectControl;

    var TOOLS = [
        { label: '🗜️ Compress PDF',  value: 'compress-pdf' },
        { label: '🔗 Merge PDF',      value: 'merge-pdf'    },
        { label: '✂️ Split PDF',      value: 'split-pdf'    },
        { label: '📝 PDF to Word',    value: 'pdf-to-word'  },
        { label: '📄 Word to PDF',    value: 'word-to-pdf'  },
        { label: '🖼️ JPG to PDF',    value: 'image-to-pdf' },
        { label: '🗃️ PDF to JPG',    value: 'pdf-to-jpg'   },
    ];

    var LAYOUTS = [
        { label: 'Normal (680px — Article / Blog)', value: 'normal'  },
        { label: 'Sidebar (340px — Widget area)',    value: 'sidebar' },
    ];

    var TOOL_LABELS = {
        'compress-pdf': 'Compress PDF',
        'merge-pdf':    'Merge PDF',
        'split-pdf':    'Split PDF',
        'pdf-to-word':  'PDF to Word',
        'word-to-pdf':  'Word to PDF',
        'image-to-pdf': 'JPG to PDF',
        'pdf-to-jpg':   'PDF to JPG',
    };

    blocks.registerBlockType( 'pdflinx/embed', {
        title:       __( 'PDFLinx Tool', 'pdflinx-embed' ),
        description: __( 'Embed a free PDF tool from PDFLinx.com', 'pdflinx-embed' ),
        category:    'embed',
        icon:        'media-document',
        keywords:    [ 'pdf', 'compress', 'merge', 'convert', 'pdflinx' ],

        attributes: {
            tool:   { type: 'string', default: 'compress-pdf' },
            layout: { type: 'string', default: 'normal'       },
        },

        edit: function( props ) {
            var tool    = props.attributes.tool;
            var layout  = props.attributes.layout;
            var compact = layout === 'sidebar';
            var width   = compact ? 340 : 680;
            var height  = compact ? 380 : 480;
            var src     = 'https://pdflinx.com/embed/' + tool + ( compact ? '?compact=true' : '' );

            return [
                el( InspectorControls, { key: 'inspector' },
                    el( PanelBody, { title: __( 'PDFLinx Settings', 'pdflinx-embed' ), initialOpen: true },
                        el( SelectControl, {
                            label:    __( 'Tool', 'pdflinx-embed' ),
                            value:    tool,
                            options:  TOOLS,
                            onChange: function( val ) { props.setAttributes( { tool: val } ); },
                        } ),
                        el( SelectControl, {
                            label:    __( 'Layout', 'pdflinx-embed' ),
                            value:    layout,
                            options:  LAYOUTS,
                            onChange: function( val ) { props.setAttributes( { layout: val } ); },
                        } )
                    )
                ),
                el( 'div', { key: 'preview', className: 'pdflinx-block-preview' },
                    el( 'div', { className: 'pdflinx-block-header' },
                        el( 'img', {
                            src: 'https://pdflinx.com/favicon.ico',
                            width: 16, height: 16,
                            style: { borderRadius: '3px' }
                        } ),
                        el( 'span', {}, 'PDFLinx — ' + ( TOOL_LABELS[ tool ] || tool ) )
                    ),
                    el( 'div', { className: 'pdflinx-block-info' },
                        el( 'p', {}, '📐 ' + width + 'px × ' + height + 'px  ·  ' + ( compact ? 'Sidebar' : 'Normal' ) + ' layout' ),
                        el( 'p', { style: { fontSize: '11px', color: '#94a3b8', marginTop: '4px' } },
                            'Live preview on frontend: ',
                            el( 'a', { href: src, target: '_blank', rel: 'noopener noreferrer' }, src )
                        )
                    )
                )
            ];
        },

        save: function() {
            return null; // Server-side render via PHP
        },
    } );

} )(
    window.wp.blocks,
    window.wp.element,
    window.wp.editor,
    window.wp.components,
    window.wp.i18n
);
