<?php
/**
 * Plugin Name:       PDFLinx Embed
 * Plugin URI:        https://pdflinx.com/embed-code
 * Description:       Embed free PDF tools from PDFLinx.com into any page or post using a shortcode or Gutenberg block.
 * Version:           1.0.0
 * Author:            PDFLinx
 * Author URI:        https://pdflinx.com
 * License:           GPL v2 or later
 * Text Domain:       pdflinx-embed
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'PDFLINX_VERSION', '1.0.0' );
define( 'PDFLINX_URL', 'https://pdflinx.com' );

// ─────────────────────────────────────────────
// 1. SHORTCODE
// Usage: [pdflinx tool="compress-pdf"]
//        [pdflinx tool="merge-pdf" layout="sidebar"]
// ─────────────────────────────────────────────

function pdflinx_shortcode( $atts ) {
    $atts = shortcode_atts( [
        'tool'   => 'compress-pdf',
        'layout' => 'normal',
    ], $atts, 'pdflinx' );

    $allowed_tools = [
        'compress-pdf', 'merge-pdf', 'split-pdf',
        'pdf-to-word',  'word-to-pdf',
        'image-to-pdf', 'pdf-to-jpg',
    ];

    $tool    = in_array( $atts['tool'], $allowed_tools ) ? $atts['tool'] : 'compress-pdf';
    $compact = $atts['layout'] === 'sidebar';

    $width  = $compact ? '340' : '680';
    $height = $compact ? '380' : '480';
    $src    = PDFLINX_URL . '/embed/' . $tool . ( $compact ? '?compact=true' : '' );

    return sprintf(
        '<div class="pdflinx-embed-wrap" style="max-width:%spx; margin:0 auto;">
            <iframe
                src="%s"
                width="100%%"
                height="%s"
                style="border:none; border-radius:16px; box-shadow:0 4px 24px rgba(0,0,0,0.10); display:block;"
                loading="lazy"
                title="PDF Tool by PDFLinx"
            ></iframe>
            <p style="text-align:center; margin-top:6px; font-size:11px; color:#94a3b8;">
                Powered by <a href="%s" target="_blank" rel="noopener noreferrer" style="color:#14b8a6;">PDFLinx.com</a>
            </p>
        </div>',
        esc_attr( $width ),
        esc_url( $src ),
        esc_attr( $height ),
        esc_url( PDFLINX_URL )
    );
}
add_shortcode( 'pdflinx', 'pdflinx_shortcode' );


// ─────────────────────────────────────────────
// 2. GUTENBERG BLOCK
// ─────────────────────────────────────────────

function pdflinx_register_block() {
    if ( ! function_exists( 'register_block_type' ) ) return;

    wp_register_script(
        'pdflinx-block-editor',
        plugins_url( 'block.js', __FILE__ ),
        [ 'wp-blocks', 'wp-element', 'wp-editor', 'wp-components', 'wp-i18n' ],
        PDFLINX_VERSION
    );

    wp_register_style(
        'pdflinx-block-editor-style',
        plugins_url( 'editor.css', __FILE__ ),
        [],
        PDFLINX_VERSION
    );

    register_block_type( 'pdflinx/embed', [
        'editor_script'   => 'pdflinx-block-editor',
        'editor_style'    => 'pdflinx-block-editor-style',
        'render_callback' => 'pdflinx_block_render',
        'attributes'      => [
            'tool'   => [ 'type' => 'string', 'default' => 'compress-pdf' ],
            'layout' => [ 'type' => 'string', 'default' => 'normal' ],
        ],
    ] );
}
add_action( 'init', 'pdflinx_register_block' );

function pdflinx_block_render( $attributes ) {
    return pdflinx_shortcode( $attributes );
}
